package com.dtlonline.shop.view;

/**
 * @author Deveik
 * @date 2019/01/24
 */
public class ShopSimplenessWithStatusDTO {
}
