package com.dtlonline.shop.controller.system;

import io.alpha.core.base.BaseController;
import org.springframework.web.bind.annotation.*;

@RestController("systemProductController")
@RequestMapping("/system")
public class ProductController extends BaseController{

}
