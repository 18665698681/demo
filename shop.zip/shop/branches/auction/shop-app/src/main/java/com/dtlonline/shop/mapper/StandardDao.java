package com.dtlonline.shop.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dtlonline.shop.model.Standard;
import org.springframework.stereotype.Repository;

@Repository
public interface StandardDao extends BaseMapper<Standard> {

}
