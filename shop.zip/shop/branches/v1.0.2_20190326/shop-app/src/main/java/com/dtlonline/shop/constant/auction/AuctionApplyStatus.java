package com.dtlonline.shop.constant.auction;

public interface AuctionApplyStatus {

    /**
     * 已申请
     */
    Integer APPLY = 1;
    /**
     * 未申请
     */
    Integer NO_APPLY = 2;
}
