package com.dtlonline.api.shop.command.store;

import io.alpha.app.core.base.BasePageObject;
import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
* Created by Mybatis Generator 2019/04/17
*/
@ApiModel
@Data
public class StoreGoodsPageDTOI extends BasePageObject {

}